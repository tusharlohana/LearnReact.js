import React from 'react'

const Nav = () => {
    return (
        <div>
           <input type="text" placeholder="city..."></input>
           <input type="button" value="Search"></input> 
        </div>
    )
}

export default Nav
